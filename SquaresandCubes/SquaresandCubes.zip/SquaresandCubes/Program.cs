﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquaresandCubes
{
    class Program
    {
        static void Main(string[] args)
        {
            // This program is going to display a tables of squares and cubes

       
            //Displaying
            Console.WriteLine("Number\tSquare\tCube");
            int x = 0;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 1;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 2;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 3;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 4;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 5;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 6;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 7;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 8;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 9;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));
            x = 10;
            Console.WriteLine("{0}\t{1}\t{2}", x, (x * x), (x * x * x));

        }
    }
}
